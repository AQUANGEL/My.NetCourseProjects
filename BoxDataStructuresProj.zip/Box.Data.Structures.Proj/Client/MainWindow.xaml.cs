﻿using BL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private InventoryManagement _Inventory;

        public MainWindow()
        {
            InitializeComponent();
            _Inventory = new InventoryManagement();
        }

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {
            int width, height;
            bool widthFlag = int.TryParse(SearchWidth.Text, out width);
            bool heightFlag = int.TryParse(SearchHeight.Text, out height);
            if (widthFlag && heightFlag)
            {
                try
                {
                    Box temp = new Box(width, height);
                    MessageBlock.Text = _Inventory.Check_Amount(temp).ToString();
                }
                catch (System.ArgumentException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBlock.Text = "Wrong input";
        }

        private void LoadGrid()
        {
            try
            {
                InventoryGrid.ItemsSource = _Inventory.GetItems();
                InventoryGrid.Items.Refresh();
                MessageBlock.Text = "";
            }
            catch (System.ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RefreshBtn_Click(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        private void SellBtn_Click(object sender, RoutedEventArgs e)
        {
            int width, height;
            bool widthFlag = int.TryParse(SearchWidth.Text, out width);
            bool heightFlag = int.TryParse(SearchHeight.Text, out height);
            try
            {
                if (widthFlag && heightFlag)
                    MessageBlock.Text = _Inventory.Sell(new Box(width, height)).ToString();
                else
                    MessageBlock.Text = "Wrong input";
            }
            catch (System.ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            int height, width, amount;
            bool widthFlag = int.TryParse(WidthAdd.Text, out width);
            bool heightFlag = int.TryParse(HeightAdd.Text, out height);
            bool amountFlag = int.TryParse(AmountAdd.Text, out amount);
            if(widthFlag&&heightFlag&&amountFlag)
            {
                try
                {
                    Box temp = new Box(width, height, amount);
                    _Inventory.Add_Box(temp);
                }
                catch (System.ArgumentException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBlock.Text = "Wrong input";
        }
    }
}
