﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListTask
{
    [Serializable]
    public class ListNode<T>
    {
        public ListNode<T> next { get; set; }
        public ListNode<T> previous { get; set; }
        public T Data { get; set; }

        public ListNode(T data)
        {
            Data = data;
        }
    }
}
