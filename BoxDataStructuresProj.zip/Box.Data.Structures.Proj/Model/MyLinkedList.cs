﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListTask
{
    [Serializable]
    public class MyLinkedListQueue<T>:IEnumerable where T : IComparable
    {
        private ListNode<T> start;
        private ListNode<T> end;

        public T First
        {
            get
            {
                if (start != null)
                    return start.Data;
                return default(T);
            }
        }
        public T Last
        {
            get
            {
                if (end != null)
                    return end.Data;
                return default(T);
            }
        }
        public void Remove(T data)
        {
            if (start != null)
            {
                if (start.Data.CompareTo(data) == 0 && start == end)
                    start = end = null;
                else
                {
                    if (start.Data.CompareTo(data) == 0)
                    {
                        start = start.next;
                        start.previous = null;
                    }
                    else
                    {
                        if (end.Data.CompareTo(data) == 0)
                        {
                            end = end.previous;
                            end.next = null;
                        }
                        else
                        {
                            ListNode<T> tmp = start;
                            while (tmp != null && tmp.Data.CompareTo(data) != 0)
                            {
                                tmp = tmp.next;
                            }
                            if (tmp != null)
                            {
                                tmp.previous.next = tmp.next;
                                tmp.next.previous = tmp.previous;
                            }
                        }
                    }
                }
            }
        }

        public void Search(T searchedData,out T tmpData)
        {
            tmpData = default(T);
            ListNode<T> tmp = start;
            while (tmp != null && tmp.Data.CompareTo(searchedData) != 0)
            {
                tmp = tmp.next;
            }
            if (tmp != null)
                tmpData = tmp.Data;
        }
        
       public void AddToFirst(T newData)
        {

            ListNode<T> newNode = new ListNode<T>(newData);
            if (start == null)
                start = end = newNode;
            else
            {
                ListNode<T> tmp = start;
                start.previous = newNode;
                start = newNode;
                start.next = tmp;

            }

        }
        public void AddToLast(T newData)
        {
            ListNode<T> newNode = new ListNode<T>(newData);
            ListNode<T> tmp = end;
            if (end == null)
                start = end = newNode;
            else
            {
                end.next = newNode;
                end = newNode;
                end.previous = tmp;
            }
            
        }

        public bool IsEmpty()
        {
            return start == null;
        }


        public void RemoveFirst()
        {
            if (start!= null && start.next != null)
            {
                start = start.next;
                start.previous = null;
            }
            else
                start= end = null;
        }
        public void RemoveLast()
        {
            if (end != null&&end.previous!=null)
            {
                end = end.previous;
                end.next = null;
            }
            else 
                end = start = null;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            ListNode<T> tmp=start;
            while (tmp != null)
            {
                sb.Append(tmp.Data + "\n");
                tmp = tmp.next;
            }
            return sb.ToString();
        }

        public IEnumerator GetEnumerator()
        {
            ListNode<T> tmp = start;
            while (tmp != null)
            {
                yield return tmp.Data;
                tmp = tmp.next;
            } 
        }
    }
}
