﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearchTree
{
    [Serializable]
    public class Node<T>
    {
        public T data { get; set; }
        public Node<T> left { get; set; }
        public Node<T> right { get; set; }

        public Node(T data)
        {
            this.data = data;
            left = right = null;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(data+ " ");
            return sb.ToString();
        }
    }
}
