﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Box //: IComparable
    {
        public int width { get; private set; }
        public int height { get; private set; }
        public DateTime lastUsedDate { get; private set; }
        public int amount { get; private set; }


        public Box(int width, int height, int amount = 1)
        {
            this.width = width;
            this.height = height;
            lastUsedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            this.amount = amount;
        }

        public void EditAmount(int amount)
        {
            lastUsedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
            this.amount += amount;
        }

        /*public override bool Equals(object obj)
        {
            if(obj is Box)
            {
                Box temp = (Box)obj;
                if(width == temp.width)
                {
                    if (height == temp.height)
                        return true;
                }
            }
            return false;
        }*/

        public override string ToString()
        {
            return "Box width is: " + width + " ,height is: " + height +
                " ,amount is: " + amount + " ,last updated on: " + lastUsedDate.ToString();
        }

        
    }
}
