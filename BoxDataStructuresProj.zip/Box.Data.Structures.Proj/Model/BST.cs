﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearchTree
{
    [Serializable]
    public class BST<T> where T : IComparable
    {
        Node<T> root = null;

        public int GetDepth()
        {
            return GetDepth(root);
        }

        private int GetDepth(Node<T> tmp)
        {
            if (tmp == null) return 0;
            int leftDepth = GetDepth(tmp.left);
            int rightDepth = GetDepth(tmp.right);
            return 1 + Math.Max(leftDepth, rightDepth);
        }

        public void Add(T newData)
        {
            Node<T> newNode = new Node<T>(newData);
            if (root == null)
                root = newNode;
            else
            {
                Node<T> tmp = root;
                Node<T> parent = null;
                while (tmp != null)
                {
                    parent = tmp;
                    if (newData.CompareTo(tmp.data) < 0)
                    //go left
                    {
                        tmp = tmp.left;
                    }
                    else  //go right
                    {
                        tmp = tmp.right;
                    }

                }
                if (newData.CompareTo(parent.data) < 0)
                {
                    parent.left = newNode;
                }
                else
                {
                    parent.right = newNode;
                }
            }

        }
        public bool IsDataExict(T Searched)
        {
            bool flag = false;
            if (root != null)
            {
                Node<T> tmp = root;
                while (tmp != null && tmp.data.CompareTo(Searched) != 0)
                {
                    if (tmp.data.CompareTo(Searched) < 0)
                    {
                        tmp = tmp.right;
                    }
                    else
                    {
                        tmp = tmp.left;
                    }
                }
                if (tmp != null)
                {
                    flag = true;
                }
            }
            return flag;
        }

        public bool IsEmpty()
        {
            return root == null;
        }
        public void SearcheData(T searchedData, out T tmpData)
        {
            tmpData = default(T);
            Node<T> tmp = root;

            while (tmp != null && tmp.data.CompareTo(searchedData) != 0)
            {
                if (tmp.data.CompareTo(searchedData) < 0)
                {
                    tmp = tmp.right;
                }
                else
                {
                    tmp = tmp.left;
                }
            }
            if (tmp != null)
            {
                tmpData = tmp.data;
            }

        }


        private bool SearchNodeAndParent(T Removed, ref Node<T> tmp, ref Node<T> Parent)
        {
            bool flag = false;
            while (tmp != null && tmp.data.CompareTo(Removed) != 0)
            {
                Parent = tmp;
                if (tmp.data.CompareTo(Removed) < 0)
                {
                    tmp = tmp.right;
                }
                else
                {
                    tmp = tmp.left;
                }
            }
            if (tmp != null) flag = true;

            return flag;
        }
        public void Remove(T Removed)
        {
            if (root == null) return;
            Node<T> tmp = root;
            Node<T> Parent = null;

            if (!SearchNodeAndParent(Removed, ref tmp, ref Parent))//if not found 
            {
                return;
            }
            else
            {
                if (tmp.right == null && tmp.left == null)//leaf
                {
                    IfLeaf(tmp, Parent);
                    return;

                }
                if (tmp.left != null ^ tmp.right != null)//one chiled
                {
                    IfOneChildren(tmp, Parent);
                    return;
                }
                IfTwoChildren(tmp, Parent);//two chiled
                return;
            }
        }

        private void IfLeaf(Node<T> RemovedNode, Node<T> parent)
        {
            if (root == RemovedNode)
            {
                root = null;
                return;
            }
            if (RemovedNode.data.CompareTo(parent.data) < 0)
            {
                parent.left = null;
                return;
            }
            else
            {
                parent.right = null;
                return;
            }
        }


        private void IfOneChildren(Node<T> RemovedNode, Node<T> parent)
        {
            if (parent == null)//the box removed is in the root
            {
                if (RemovedNode.left == null)
                {

                    root = root.right;
                    return;

                }
                else
                {
                    root = root.left;
                    return;
                }
            }
            if (RemovedNode.data.CompareTo(parent.data) >= 0)
            {
                if (RemovedNode.right == null)
                {
                    parent.right = RemovedNode.left;

                }
                else parent.right = RemovedNode.right;
            }
            else
            {
                if (RemovedNode.right == null)
                {
                    parent.left = RemovedNode.left;

                }
                else parent.left = RemovedNode.right;
            }
        }
        private void IfTwoChildren(Node<T> RemovedNode, Node<T> parent)
        {
            Node<T> child = RemovedNode.right;
            if (child.right == null && child.left == null)//child is leaf
            {
                child.left = RemovedNode.left;
                RemovedNode.right = null;
                if (parent == null)//removed node is the root
                {
                    root = child;
                    return;
                }
                else//if parent is not null, redrecting one of his sides to the child is needed
                {
                    if (RemovedNode.data.CompareTo(parent.data) < 0)
                    {
                        parent.left = child;
                        return;
                    }
                    else
                        parent.right = child;
                    return;
                }

            }
            if (child.left == null)//which mean the child is the smallest of all the values                         which are bigger then the data removed
            {
                if (parent == null)
                {
                    root.right = child.right;
                    child.left = root.left;
                    root = child;
                    return;
                }
                else
                {
                    parent.right = child;
                    child.left = RemovedNode.left;
                    return;
                }
            }

            //child have smaller values in its tree
            Node<T> newDad = null;
            while (child.left != null)
            {
                newDad = child;
                child = child.left;
            }
            newDad.left = child.right;
            child.right = RemovedNode.right;
            child.left = RemovedNode.left;


            if (parent == null)
            {
                root = child;
                return;
            }
            else
            {
                if (RemovedNode.data.CompareTo(parent.data) < 0)
                {
                    parent.left = child;

                    return;
                }
                parent.right = child;

                return;
            }

        }

        public bool SearchSuitableNode(ref T searchedData)
        {
            bool flag = false; //bool flag to retun function outcome

            Node<T> tmp = root;
            Node<T> parent = null;
            while (tmp != null && tmp.data.CompareTo(searchedData) != 0)//searching data loop
            {
                if (searchedData.CompareTo(tmp.data) < 0)
                {
                    parent = tmp;
                    tmp = tmp.left;
                    flag = true;
                }
                else
                {
                    tmp = tmp.right;//no reason to keep nodes with data smaller than the one we looking for
                }

            }
            if (tmp == null && parent != null)//we found a bigger data
            {
                searchedData = parent.data;
            }
            if (tmp != null)//we found the exact data
            {
                searchedData = tmp.data;
                flag = true;
            }
            return flag;
        }

        public override string ToString()
        {
            return display(root); //recarsion method that get the root and therefor can print the whole tree
        }



        private string display(Node<T> tmp)
        {

            if (tmp == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.Append(display(tmp.left));
            sb.Append(tmp);
            sb.Append(display(tmp.right));

            return sb.ToString();
        }
    }
}
