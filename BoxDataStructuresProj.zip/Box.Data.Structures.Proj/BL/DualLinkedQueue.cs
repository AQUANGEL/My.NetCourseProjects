﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
     internal class DualLinkedQueue
    {

        private DualLinkedNode _first { get; set; }
        private DualLinkedNode _last { get; set; }
        

        public DualLinkedQueue()
        {
            _first = _last = null;
        }

        public DualLinkedNode Add(Box boxToAdd)
        {
            DualLinkedNode temp = new DualLinkedNode(boxToAdd.lastUsedDate);
            if (IsEmpty())
            {
                _first = _last = temp;
                return _first;
            }
            else
            {
                temp.next = _last;
                _last.prev = temp;
                _last = temp;
                return _last;
            }
        }

        public List<DataTreeNode> Delete_Unused(/* time parameter from timer*/)
        {
            //to do - remove nodes according to date configed, create assisting method to remove node and relink
            return null;
        }

        public void Update(DualLinkedNode nodeFromTree, Box boxToAdd)
        {
            nodeFromTree.date = boxToAdd.lastUsedDate; //update date
            ReInsertNode(nodeFromTree); //reinsert (unless its in the end)
        }

        private void ReInsertNode(DualLinkedNode nodeFromTree)
        {
            
            if (nodeFromTree==_first) 
            {
                _first = _first.prev;
                _first.next = null;
                InsertionToEnd(nodeFromTree);
            }
            else
            {
                if(nodeFromTree!=_last)
                {
                    nodeFromTree.prev.next = nodeFromTree.next;
                    nodeFromTree.next.prev = nodeFromTree.prev;
                    InsertionToEnd(nodeFromTree);
                }
            }
        }

        private void InsertionToEnd(DualLinkedNode nodeToInsert) 
        {
            _last.prev = nodeToInsert;
            nodeToInsert.next = _last;
            _last = nodeToInsert;
            _last.prev = null;
        }

        public bool IsEmpty()
        {
            return _first == null && _last == null;
        }
    }
}
