﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    internal class WidthTree
    {
        
        private WidthTreeNode _root; 
        /*holds int height
         * bigger node
         * smaller node
         * parent node
         * data tree  - holds int height, amount,link to date node,nodes smaller and bigger, parent node 
         * 
         */

        public WidthTree()
        {
            _root =null;
        }

        public DataTreeNode Add(Box boxToAdd)
        {
            if(_root==null)
            { //put in a seperate method?
                
                _root = new WidthTreeNode(boxToAdd.width);
                _root.dataTree = new DataTree(_root);
                return _root.dataTree.Add(boxToAdd);
            }
            return AddNotEmptyTree(boxToAdd);
        }

        private DataTreeNode AddNotEmptyTree(Box boxToAdd)
        {
            WidthTreeNode temp = _root;
            WidthTreeNode parent = null;
            while (temp != null)
            {
                if (temp.width == boxToAdd.width)
                    return temp.dataTree.Add(boxToAdd);
                parent = temp;
                if (temp.width < boxToAdd.width)
                    temp = temp.bigger;
                else
                    temp = temp.smaller;
            }
            if (boxToAdd.width < parent.width)
                return CreateNewNode(parent, boxToAdd, -1);
            else
                return CreateNewNode(parent, boxToAdd, 1);
        }

        private DataTreeNode CreateNewNode(WidthTreeNode parent,Box boxToAdd, int locationForNode)
        {
            WidthTreeNode temp = new WidthTreeNode(boxToAdd.width);
            temp.parent = parent;
            temp.dataTree = new DataTree(temp);
            if (locationForNode < 0)
                parent.smaller = temp;
            else
                parent.bigger = temp;

            return temp.dataTree.Add(boxToAdd);
        }

        

        public Box Find_Gifting_Box(int minWidth, int minHeight) //can add amount parameter
        {
            WidthTreeNode temp = _root;
            while (temp != null)
            {
                if (temp.width == minWidth)
                    return Create_Box(temp, minHeight); //reduce amount by 1
                else
                {
                    if(temp.width > minWidth && temp.smaller == null)
                        return Create_Box(temp, minHeight);
                }
                if (temp.width < minWidth)
                    temp = temp.bigger;
                else
                    temp = temp.smaller;
            }
            return null;
        }

        private Box Create_Box(WidthTreeNode boxNode, int minHeight)
        {
            DataTreeNode temp = boxNode.dataTree.Find_Gifting_Box(minHeight);
            if(temp!=null)
                return new Box(boxNode.width, temp.height);
            return null;
        }


        public int Check_Amount(int width, int height)
        {
            WidthTreeNode temp = _root;
            while (temp != null)
            {
                if (temp.width == width)
                    return temp.dataTree.Check_Amount(height);
                if (temp.width < width)
                    temp = temp.bigger;
                else
                    temp = temp.smaller;
            }

            return 0;
        }

        public void Delete(DataTreeNode deletable)
        {
            throw new NotImplementedException();
        }
    }
}
