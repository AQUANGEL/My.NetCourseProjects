﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    [Serializable]
    public class DateQueueData : IComparable
    {
        public int width { get; private set; }
        public int height { get; private set; }
        public DateTime lastUsed { get; private set; }


        public DateQueueData(int width, int height, DateTime date)
        {
            this.width = width;
            this.height = height;
            lastUsed = new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Day, date.Second);
        }

        public int WidthHeightCompareTo(DateQueueData other)
        {
            if (width.CompareTo(other.width) == 0 && height.CompareTo(other.height) == 0)
                return 0;
            return -1;
        }
        public int CompareTo(object obj)
        {
            if (obj is DateQueueData)
            {
                DateQueueData toCompare = (DateQueueData)obj;
                if (width.CompareTo(toCompare.width) == 0 && height.CompareTo(toCompare.height) == 0)
                    return 0;
                return -1;
            }
            throw new System.ArgumentException("Not a box");
        }
        public override string ToString()
        {
            return "Width: " + width + " Height: " + height + " Last Update: " + lastUsed;
        }
    }
}
