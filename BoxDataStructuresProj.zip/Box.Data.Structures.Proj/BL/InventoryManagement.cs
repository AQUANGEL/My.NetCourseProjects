﻿using DAL;
using LinkedListTask;
using Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace BL
{
    public class InventoryManagement
    {
        private FileManager _DataBase;
        private BoxWidthsTree _BoxesTree;
        private MyLinkedListQueue<DateQueueData> _DatesQueue;
        private Timer _timer;
        private readonly int timerTime = int.Parse(ConfigurationManager.AppSettings.Get("TimerInSeconds"));
        private readonly TimeSpan relevant = new TimeSpan
            (
            int.Parse(ConfigurationManager.AppSettings.Get("Days")),
            int.Parse(ConfigurationManager.AppSettings.Get("Hours")),
            int.Parse(ConfigurationManager.AppSettings.Get("Minutes")),
            int.Parse(ConfigurationManager.AppSettings.Get("Seconds"))
            );

        public InventoryManagement()
        {
            _DataBase = new FileManager();
            Load();
            _timer = new Timer();
            _timer.Interval = timerTime;
            _timer.Elapsed += Delete_Unused;
            _timer.AutoReset = true;
            _timer.Enabled = true;
        }
        /*
         * event to delete old boxes
         */
        private void Delete_Unused(object sender, ElapsedEventArgs e)
        {
            DateTime lastUseDate = DateTime.Now.Subtract(relevant);
            while((!_DatesQueue.IsEmpty())&&(_DatesQueue.First.lastUsed.CompareTo(lastUseDate)<0))
            {
                int height, width;
                height = _DatesQueue.First.height;
                width = _DatesQueue.First.width;
                _BoxesTree.RemoveBox(width, height);
                _DatesQueue.RemoveFirst();
            }
            Save();
        }


        /*
         * update box date in queue
         * add box or amount to tree
         */
        public void Add_Box(Box boxToAdd)
        {
            DateQueueData newData = new DateQueueData(boxToAdd.width, boxToAdd.height, boxToAdd.lastUsedDate);
            DateQueueData tmp;
            _DatesQueue.Search(newData, out tmp);
            if (tmp != null)
                _DatesQueue.Remove(tmp);
            _DatesQueue.AddToLast(newData);
            _BoxesTree.Add(boxToAdd.width, boxToAdd.height, boxToAdd.amount);
            Save();
        }
        /*
         * check amount of recieved sizes
         */
        public int Check_Amount(Box temp)
        {
            return _BoxesTree.CheckAmount(temp.width, temp.height);
        }
        /*
         * sell a box according to demands
         * return message:
         * if box found - box details
         * if box found and amount goes too low - add a warning to the last message
         * if box not found state which of the sizes were not fount - width/hieght/both
         */
        public string Sell(Box minimalBoxSize)
        {
            Box boxFound;
            string message;
            message = _BoxesTree.Sell(minimalBoxSize.width, minimalBoxSize.height, out boxFound);
            if(boxFound!=null)
            {
                DateQueueData newData = new DateQueueData(boxFound.width, boxFound.height, boxFound.lastUsedDate);
                DateQueueData tmp;
                _DatesQueue.Search(newData, out tmp);
                if (tmp != null)
                    _DatesQueue.Remove(tmp);
                if (_BoxesTree.CheckAmount(boxFound.width, boxFound.height) != 0)
                    _DatesQueue.AddToLast(newData);
                Save();
                return boxFound.ToString() + message;
            }
            return message;
        }

        private void Load()
        {
            _DatesQueue = _DataBase.LoadQueue();
            _BoxesTree = _DataBase.LoadTree();
        }

        private void Save()
        {
            _DataBase.SaveBoxes(_BoxesTree);
            _DataBase.SaveDates(_DatesQueue);
        }

        public ObservableCollection<Box> GetItems()
        {
            
            List<Box> tempList = new List<Box>();
            foreach(DateQueueData date in _DatesQueue)
            {
                tempList.Add(new Box(date.width, date.height, date.lastUsed, _BoxesTree.CheckAmount(date.width, date.height)));
            }
            ObservableCollection<Box> view = new ObservableCollection<Box>(tempList);
            return view;
        }


    }
}
