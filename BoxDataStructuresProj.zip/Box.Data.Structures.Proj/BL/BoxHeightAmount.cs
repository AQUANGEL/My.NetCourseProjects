﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading.Tasks;
using Model;

namespace BL
{
    [Serializable]
    internal class BoxHeightAmount:IComparable
    {
        private readonly int max = int.Parse(ConfigurationManager.AppSettings.Get("Max_Amount"));
        private readonly int min = int.Parse(ConfigurationManager.AppSettings.Get("Min_Amount"));

        public int height { get; private set; }
        public int amount { get; private set; }


        public BoxHeightAmount(int height, int amount)
        {
            this.height = height;
            if (amount > max)
                amount = max;
            else
                this.amount = amount;
        }

        public void AddAmount(int amountToAdd)
        {
            this.amount += amountToAdd;
            if (this.amount <= 0)
                this.amount = 0;
        }

        public int CompareTo(object obj)
        {
            if(obj is BoxHeightAmount)
            {
                BoxHeightAmount toCompare = (BoxHeightAmount)obj;
                return height.CompareTo(toCompare.height);
            }
            throw new System.ArgumentException("Wrong input, please enter proper height to compare ");
        }

        public string Sell(int amount = 1)
        {
            string s = "";
            this.amount-=amount;
            if (amount < min)
                s = "\nAmount of Boxes is below the minimum.";
            if (this.amount <= 0)
                this.amount = 0;
            return s;
        }
    }
}
