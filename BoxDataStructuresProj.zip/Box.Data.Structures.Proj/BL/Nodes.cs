﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    internal class WidthTreeNode
    {
        public int width { get; set; }
        public WidthTreeNode smaller { get; set; }
        public WidthTreeNode bigger { get; set; }
        public WidthTreeNode parent { get; set; }
        public DataTree dataTree { get; set; }

        public WidthTreeNode(int width)
        {
            this.width = width;
            smaller = bigger = parent = null;
        }

        public bool IsLeaf()
        {
            return smaller == null && bigger == null;
        }
    }





    internal class DualLinkedNode
    {
        public DateTime date { get; set; }
        public DualLinkedNode prev { get; set; }
        public DualLinkedNode next { get; set; }
        public DataTreeNode _Location_In_Tree { get; set; } 

        public DualLinkedNode(DateTime date)
        {
            this.date = new DateTime(date.Year, date.Month, date.Day);
            prev = next = null;
            _Location_In_Tree = null;
        }
    }
}
