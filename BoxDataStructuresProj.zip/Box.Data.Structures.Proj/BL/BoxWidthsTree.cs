﻿using BinarySearchTree;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    [Serializable]
    public class BoxWidthsTree
    {
        private BST<BoxWidth> _BoxWidthsTree;
        public BoxWidthsTree()
        {
            _BoxWidthsTree = new BST<BoxWidth>();
        }

        public void Add(int width, int height, int amount)
        {
            BoxHeightAmount newData = new BoxHeightAmount(height, amount);
            BoxWidth newWidth = new BoxWidth(width, newData);
            BoxWidth temp;

            _BoxWidthsTree.SearcheData(newWidth, out temp);
            if (temp == null)
                _BoxWidthsTree.Add(newWidth);
            else
                AddToExisting(temp, ref newData);
        }

        private void AddToExisting(BoxWidth width, ref BoxHeightAmount newData)
        {
            width.dataTree.Add(ref newData);
        }

        public void Remove(int width)
        {
            BoxHeightAmount empty = new BoxHeightAmount(0, 0);
            BoxWidth toRemove = new BoxWidth(width, empty);
            _BoxWidthsTree.Remove(toRemove);
        }

        public void RemoveBox(int width, int height)
        {
            BoxHeightAmount innerDataToRemove = new BoxHeightAmount(height, 0);
            BoxWidth searchedData = new BoxWidth(width, innerDataToRemove);
            BoxWidth tempWidth;
            _BoxWidthsTree.SearcheData(searchedData, out tempWidth);
            if (tempWidth != null)
            {
                BoxHeightAmount tempData;
                tempWidth.dataTree.SearcheData(innerDataToRemove, out tempData);
                if (tempData != null)
                    tempWidth.dataTree.Remove(innerDataToRemove);
                if (tempWidth.dataTree.IsEmpty())
                    _BoxWidthsTree.Remove(searchedData);
            }
        }
        public string Sell(int width, int height, out Box boxToSell)
        {
            boxToSell = null;
            string message = "";
            BoxHeightAmount innerData = new BoxHeightAmount(height, 1);
            BoxWidth searchedData = new BoxWidth(width, innerData);
            if (_BoxWidthsTree.SearchSuitableNode(ref searchedData))
            {
                message = "width found is: " + searchedData.width.ToString();
                if (searchedData.dataTree.SearchSuitableNode(ref innerData))
                {
                    boxToSell = new Box(searchedData.width, innerData.height);
                    message = innerData.Sell();
                    if (innerData.amount == 0)
                        searchedData.dataTree.Remove(innerData);
                    if (searchedData.dataTree.IsEmpty())//if the height sold was the last one in this width
                        Remove(searchedData.width);
                }
                else
                    message += " Height not found! ";
            }
            else
                message = " Width not found! ";
            return message;
        }

        public int CheckAmount(int width, int height)
        {
            int amount = 0;
            BoxHeightAmount innerData = new BoxHeightAmount(height, 0);
            BoxWidth widthToSearch = new BoxWidth(width, innerData);
            BoxWidth temp;
            _BoxWidthsTree.SearcheData(widthToSearch, out temp);
            if (temp != null)
            {
                BoxHeightAmount tmpData;
                temp.dataTree.SearcheData(innerData, out tmpData);
                if (tmpData != null)
                    amount = tmpData.amount;
            }
            return amount;
        }
    }
}

