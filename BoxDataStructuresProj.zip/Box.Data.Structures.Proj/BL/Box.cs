﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Box //: IComparable
    {
        public int width { get; private set; }
        public int height { get; private set; }
        public DateTime lastUsedDate { get; private set; }
        public int amount { get; private set; }


        public Box(int width, int height, int amount = 1)
        {
            this.width = width;
            this.height = height;
            this.amount = amount;
            lastUsedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day,
                DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            InputValidation();
        }

        public Box(int width, int height, DateTime date, int amount = 1)
        {
            this.width = width;
            this.height = height;
            lastUsedDate = new DateTime(date.Year, date.Month, date.Day,
                date.Hour, date.Minute, date.Second);
            this.amount = amount;
            InputValidation();
        }

        private void InputValidation()
        {
            bool flag = false;
            string s = "";
            if(width<0)
            {
                s += "Ileagal width \n";
                flag = true;
            }
            if (height < 0)
            {
                s += "Ileagal height \n";
                flag = true;
            }
            if (amount < 0)
            {
                s += "Ileagal amount \n";
                flag = true;
            }
            if (flag)
                throw new System.ArgumentException(s);
        }

        public void EditAmount(int amount)
        {
            lastUsedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day,
                DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            this.amount += amount;
            if (amount < 0)
                amount = 0;
        }

        /*public override bool Equals(object obj)
        {
            if(obj is Box)
            {
                Box temp = (Box)obj;
                if(width == temp.width)
                {
                    if (height == temp.height)
                        return true;
                }
            }
            return false;
        }*/

        public override string ToString()
        {
            return "Box width is: " + width + " ,height is: " + height +
                " ,amount is: " + amount + " ,last updated on: " + lastUsedDate.ToString();
        }

        
    }
}
