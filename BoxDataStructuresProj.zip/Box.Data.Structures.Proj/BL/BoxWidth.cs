﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    [Serializable]
    internal class BoxWidth : IComparable
    {
        public int width { get; private set; }
        public BoxDataTree dataTree;

        public BoxWidth(int width, BoxHeightAmount data)
        {
            this.width = width;
            dataTree = new BoxDataTree();
            dataTree.Add(ref data);
        }

        public int CompareTo(object obj)
        {
            if(obj is BoxWidth)
            {
                BoxWidth toCompare = (BoxWidth)obj;
                return width.CompareTo(toCompare.width);
            }
            throw new System.ArgumentException("Wrong Imput, please enter proper width to compare.");
        }
    }
}
