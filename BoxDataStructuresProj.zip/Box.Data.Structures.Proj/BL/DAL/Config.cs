﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    internal class Config
    {
        private static readonly string CurrentDirectoryPath = Directory.GetCurrentDirectory();
        private static readonly string DataFolderPath = Path.GetFullPath(Path.Combine(CurrentDirectoryPath, @"..\..\.."));
        public static readonly string TreePath = string.Format("{0}{1}", DataFolderPath, @"\BoxesTree.txt");
        public static readonly string QueuePath = string.Format("{0}{1}", DataFolderPath, @"\DatesQueue.txt");
    }
}
