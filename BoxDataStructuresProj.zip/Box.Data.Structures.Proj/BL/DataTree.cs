﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace BL
{
    internal class DataTree
    {
        private WidthTreeNode parentWidthTree;
        private DataTreeNode _root;
        /*holds:
         * height
         * amount
         * dateNode
         */

        public DataTree(WidthTreeNode parent)
        {
            parentWidthTree = parent;
            _root = null;
        }

        public DataTreeNode Add(Box boxToAdd)
        {
            if (_root == null)
            { //put in a seperate method?

                _root = new DataTreeNode(boxToAdd.height, boxToAdd.amount);
                return _root;
            }
            return AddNotEmptyTree(boxToAdd);
        }

        private DataTreeNode AddNotEmptyTree(Box boxToAdd)
        {
            DataTreeNode temp = _root;
            DataTreeNode parent = null;
            while (temp != null)
            {
                if (temp.height == boxToAdd.height)
                    return temp.AddAmount(boxToAdd.amount);
                parent = temp;
                if (temp.height < boxToAdd.height)
                    temp = temp.bigger;
                else
                    temp = temp.smaller;
            }
            if (boxToAdd.height < parent.height)
                return CreateNewNode(parent, boxToAdd, -1);
            else
                return CreateNewNode(parent, boxToAdd, 1);
        }

        private DataTreeNode CreateNewNode(DataTreeNode parent, Box boxToAdd, int locationForNode)
        {
            DataTreeNode temp = new DataTreeNode(boxToAdd.height, boxToAdd.amount);
            temp.parent = parent;
            if (locationForNode < 0)
                parent.smaller = temp;
            else
                parent.bigger = temp;
            return temp;
        }

        public DataTreeNode Find_Gifting_Box(int minHeight)
        {
            DataTreeNode temp = _root;
            while (temp != null)
            {
                if (temp.height == minHeight)
                    return temp.Sell(); //reduce amount by 1
                else
                {
                    if (temp.height > minHeight && temp.smaller == null)
                        return temp.Sell();
                }
                if (temp.height < minHeight)
                    temp = temp.bigger;
                else
                    temp = temp.smaller;
            }
            return null;
        }

        public int Check_Amount(int height)
        {
            DataTreeNode temp = _root;
            while (temp != null)
            {
                if (temp.height == height)
                    return temp.amount;
                if (temp.height < height)
                    temp = temp.bigger;
                else
                    temp = temp.smaller;
            }

            return 0;
        }



    }
}
