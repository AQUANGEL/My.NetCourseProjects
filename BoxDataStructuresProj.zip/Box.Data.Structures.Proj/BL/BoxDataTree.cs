﻿using BinarySearchTree;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    [Serializable]
    internal class BoxDataTree
    {
        private BST<BoxHeightAmount> dataTree;

        public BoxDataTree()
        {
            dataTree = new BST<BoxHeightAmount>();
        }

        public void SearcheData(BoxHeightAmount searchedData, out BoxHeightAmount tmpData)
        {
            dataTree.SearcheData(searchedData, out tmpData);
        }

        public void Add(ref BoxHeightAmount newData)
        {
            BoxHeightAmount temp;
            dataTree.SearcheData(newData, out temp);
            if (temp == null)
                dataTree.Add(newData);
            else
                temp.AddAmount(newData.amount);
        }

        public void Remove(BoxHeightAmount removed)
        {
            dataTree.Remove(removed);
        }
        public bool IsEmpty()
        {
            return dataTree.IsEmpty();
        }

        public bool SearchSuitableNode(ref BoxHeightAmount data)
        {
            return dataTree.SearchSuitableNode(ref data);
        }

    }
}
