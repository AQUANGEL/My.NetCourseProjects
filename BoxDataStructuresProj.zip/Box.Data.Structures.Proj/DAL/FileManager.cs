﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using BL;
using System.Runtime.Serialization.Formatters.Binary;

namespace DAL
{
    public class FileManager
    {
        IFormatter formatter;
        Stream stream;

        public FileManager()
        {
            formatter = new BinaryFormatter();
        }

        /*
         * loading the inventory from configured file path using binary serialization
         */
        public BoxWidthsTree LoadTree()
        {
            BoxWidthsTree inventoryTemp = null;

            try
            {
                stream = new FileStream(Config.TreePath, FileMode.Open, FileAccess.Read, FileShare.Read);
                inventoryTemp = (BoxWidthsTree)formatter.Deserialize(stream);
            }
            catch (FileNotFoundException)
            {
                throw new System.ArgumentException("Loading exception: File not found");
            }
            finally
            {
                stream.Close();
            }
            return inventoryTemp;
        }

        public DateQueueData LoadQueue()
        {
            DateQueueData inventoryTemp = null;

            try
            {
                stream = new FileStream(Config.QueuePath, FileMode.Open, FileAccess.Read, FileShare.Read);
                inventoryTemp = (DateQueueData)formatter.Deserialize(stream);
            }
            catch (FileNotFoundException)
            {
                throw new System.ArgumentException("Loading exception: File not found");
            }
            finally
            {
                stream.Close();
            }
            return inventoryTemp;
        }

        /*
         * Saving file to the configured filepath using binary serialization
         */
        public void SaveInventory(BoxWidthsTree tree, DateQueueData queue)
        {
            try
            {
                stream = new FileStream(Config.TreePath, FileMode.Create, FileAccess.Write, FileShare.None);
                formatter.Serialize(stream, tree);
                stream = new FileStream(Config.QueuePath, FileMode.Create, FileAccess.Write, FileShare.None);
                formatter.Serialize(stream, queue);
            }
            catch (SerializationException e)
            {
                throw new System.ArgumentException("Save exception :" + e.Message);
            }
            finally
            {
                stream.Close();
            }

        }
    }
}
