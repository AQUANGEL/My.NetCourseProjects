﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;

namespace Client.Models
{
    public class ProductsViewModel
    {
        [Key]
        [Display(AutoGenerateField =false)]
        public int ProductId { get; set; }

        [Display(AutoGenerateField = false)]
        public int OwnerId { get; set; }

        [Display(AutoGenerateField = false)]
        public int? BuyerId { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper title"), MaxLength(50)]
        [DisplayName("Title")]
        public string Title { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper Description"), MaxLength(500)]
        [DisplayName("Short Description")]
        public string ShortDescription { get; set; }

        [DisplayName("Long Description")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper Description"), MaxLength(4000)]
        public string LongDescription { get; set; }

        [Required]
        [DisplayName("Publication Date")]
        public DateTime Date { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper price")]
        [DisplayName("Price")]
        [Range(0,Double.MaxValue,ErrorMessage = "Price too low")]
        public double Price { get; set; }

        [Display(AutoGenerateField = false)]
        public int State { get; set; }

        public List<HttpPostedFileBase> Files { get; set; }

        public ProductsViewModel() { }

        public ProductsViewModel(Product productToView)
        {
            this.ProductId = productToView.ProductId;
            this.OwnerId = productToView.OwnerId;
            this.Title = productToView.Title;
            this.ShortDescription = productToView.ShortDescription;
            this.LongDescription = productToView.LongDescription;
            this.Date = productToView.Date;
            this.State = productToView.State;
        }

        
    }
}