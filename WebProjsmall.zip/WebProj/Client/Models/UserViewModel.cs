﻿using Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Client.Models
{
    public class UserViewModel
    {
        [Required(AllowEmptyStrings =false,ErrorMessage ="Please enter proper first name"), MaxLength(50)]
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper last name"), MaxLength(50)]
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [Required]
        [DisplayName("Birth Date")]
        public DateTime BirthDate { get; set; }
        [EmailAddress, MaxLength(50)]
        [DisplayName("E-Mail")]
        public string Email { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper user name"), MaxLength(50)]
        [DisplayName("User Name")]
        public string UserName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter password"), MaxLength(50)]
        [DisplayName("Password")]
        public string Password { get; set; }
        [Required, MaxLength(50)]
        [DisplayName("Confirm Password")]
        [Compare("Password", ErrorMessage = "Password mismatch")]
        public string ConfirmPassword { get; set; }

        public UserViewModel() { }
        public UserViewModel(User user)
        {
            this.FirstName = user.FirstName;
            this.LastName = user.LastName;
            this.UserName = user.UserName;
            this.Email = user.Email;
            this.BirthDate = user.BirthDate;
        }

    }
}