﻿using BL;
using Client.Models;
using Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Client.Services
{
    public static class Services
    {
        public static byte[] ConverImageToByteArray(HttpPostedFileBase image)
        {
            if (image != null && image.ContentLength > 0)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    image.InputStream.CopyTo(ms);
                    return ms.ToArray();
                }
            }
            else
                return null;
        }

        public static Product ConvertVMProductToDBProduct(ProductsViewModel productToDB, LoginManager manager,List<HttpPostedFileBase> Images)
        {
            Product temp = new Product();
            //temp.Buyer=SetBuyer(productToDB, manager);
            temp.Date= productToDB.Date;
            temp.LongDescription= productToDB.LongDescription;
            temp.OwnerId= productToDB.OwnerId;
            temp.Owner= manager.FindUserByID(productToDB.OwnerId);
            temp.Price= productToDB.Price;
            temp.ShortDescription= productToDB.ShortDescription;
            temp.State= productToDB.State;
            temp.Title= productToDB.Title;
            temp.Image1= ConverImageToByteArray(Images[0]);
            temp.Image2= ConverImageToByteArray(Images[1]);
            temp.Image3= ConverImageToByteArray(Images[2]);
            return temp;

        }

        public static User ConverVMUserToUser(UserViewModel user, int id)
        {
            User temp = new User();
            temp.BirthDate= user.BirthDate;
            temp.Email= user.Email;
            temp.FirstName= user.FirstName;
            temp.LastName= user.LastName;
            temp.Password= user.Password;
            temp.UserName= user.UserName;
            if (id > 0)
                temp.UserId = id;
            return temp;
        }

        /*private static User SetBuyer(ProductsViewModel productToDB, LoginManager manager)
        {
            int id;
            if(productToDB.BuyerId!=null)
            {
                id = (int)productToDB.BuyerId;
                return manager.FindUserByID(id);
            }
            return null;
        }*/


    }
}