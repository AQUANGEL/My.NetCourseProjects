﻿using Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Client.InfraStructure
{
    public class MyFilter : ActionFilterAttribute, IExceptionFilter
    {
        private static object WriterLock = new object();

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string num ="";
            if (filterContext.RouteData.Values["num"] != null)
                num = filterContext.RouteData.Values["num"].ToString();
            FilterLog(filterContext.RouteData.Values["controller"].ToString(),
                filterContext.RouteData.Values["action"].ToString(),
                num);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            string num = "";
            if (filterContext.RouteData.Values["num"] != null)
                num = filterContext.RouteData.Values["num"].ToString();
            FilterLog(filterContext.RouteData.Values["controller"].ToString(),
                filterContext.RouteData.Values["action"].ToString(),
                num);
        }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            string num = "";
            if (filterContext.RouteData.Values["num"] != null)
                num = filterContext.RouteData.Values["num"].ToString();
            FilterLog(filterContext.RouteData.Values["controller"].ToString(),
                filterContext.RouteData.Values["action"].ToString(),
                num);
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            string num = "";
            if (filterContext.RouteData.Values["num"] != null)
                num = filterContext.RouteData.Values["num"].ToString();
            FilterLog(filterContext.RouteData.Values["controller"].ToString(),
                filterContext.RouteData.Values["action"].ToString(),
                num);
        }

        public void OnException(ExceptionContext filterContext)
        {
            string num = filterContext.Exception.Message;
            if (filterContext.RouteData.Values["num"] != null)
                num = filterContext.RouteData.Values["num"].ToString();
            FilterLog(filterContext.RouteData.Values["controller"].ToString(),
                filterContext.RouteData.Values["action"].ToString(),
                num);
        }

        private void FilterLog(string controller, string action, string num)
        {
            string message = string.Format("{0} Controller: {1}, Action: {2}, Parameters: {3} \n",
                DateTime.Now.ToString(), controller,
                action, num);
            lock(WriterLock)
            {
                File.AppendAllText(Config.ClientLogFilePath, message.ToString());
            }
        }
    }
}