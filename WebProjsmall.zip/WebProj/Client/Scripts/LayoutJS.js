﻿function ProrblemAlert(message)
{
    alert(message);
}