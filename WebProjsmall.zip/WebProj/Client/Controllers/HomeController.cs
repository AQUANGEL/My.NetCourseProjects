﻿using BL;
using Client.InfraStructure;
using Client.Models;
using Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;


namespace Client.Controllers
{
    public class HomeController : Controller
    {
        private LoginManager _loginManager;
        private ProductsManager _productManager;

        public HomeController()
        {
            _loginManager = new LoginManager();
            _productManager = new ProductsManager();

        }
        // GET: Home
        [MyFilter]
        public ActionResult Index()
        {
            var products = _productManager.GetAllProducts();
            return View(products);
        }
        [MyFilter]
        public ActionResult About()
        {
            return View("About");
        }
        [HttpPost]
        [MyFilter]
        public ActionResult Login(string userName, string password)
        {
            StringBuilder s = new StringBuilder("");
            if(userName != null&& userName.Length>0)
            {
                if (password != null && password.Length > 0)
                {
                    string res = _loginManager.Login(userName, password);
                    if (res.Equals("Login"))
                    {
                        User temp = _loginManager.FindUser(userName);
                        HttpCookie userCookie = new HttpCookie("UserInfo");
                        userCookie["ID"] = temp.UserId.ToString();
                        userCookie["UserName"] = temp.UserName;
                        userCookie.Expires = DateTime.Now.AddDays(1d);
                        Response.Cookies.Add(userCookie);
                    }
                    else
                        if (!res.Equals("Lost connection"))
                            TempData["AlertMessage"] = res;
                }
                else
                    s.Append("Please enter password.");
            }
            else
                s.Append("Please enter user name.");
            if(TempData["AlertMessage"] == null)
                TempData["AlertMessage"] = s.ToString();
            return RedirectToAction("Index");
        }
        [MyFilter]
        public ActionResult Logout()
        {
            HttpCookie userCookie = Response.Cookies["UserInfo"];
            userCookie["ID"] = null;
            userCookie["UserName"] = null;
            userCookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(userCookie);

            return RedirectToAction("Index");
        }
        [MyFilter]
        public ActionResult Sell()
        {
            if (Request.Cookies["UserInfo"]!= null)
            {
                int id;
                string cookieID = Request.Cookies["UserInfo"]["ID"];
                if (int.TryParse(cookieID, out id))
                    return View("Sell");
            }
            TempData["AlertMessage"] = "Wrong user details - must be logged in.";
            return RedirectToAction("Index");
        }
        [HttpPost]
        [MyFilter]
        public ActionResult Sell(ProductsViewModel productToAdd)
        {
            int id;
            string cookieID = Request.Cookies["UserInfo"]["ID"];
            if (int.TryParse(cookieID, out id))
            {
                if (ModelState.IsValid)
                {
                    productToAdd.OwnerId = id;
                    productToAdd.State = 1;
                    var product = Services.Services.ConvertVMProductToDBProduct(productToAdd, _loginManager, productToAdd.Files);
                    _productManager.AddProduct(product);
                    return RedirectToAction("Index");
                }
                else
                    TempData["AlertMessage"] = "Model state is not valid";
            }
            else
                TempData["AlertMessage"] = "Wrong user details - must be logged in.";
            return View("Sell");
        }
        [MyFilter]
        public ActionResult RegisterOrChangeDetails()
        {
            if (Request.Cookies["UserInfo"] != null)
            {
                int id;
                string cookieID = Request.Cookies["UserInfo"]["ID"];
                if (int.TryParse(cookieID, out id))
                {
                    UserViewModel temp = new UserViewModel(_loginManager.FindUserByID(id));
                    return View("Profile", temp);
                }
            }
            return View("SignUp");
        }
        [HttpPost]
        [MyFilter]
        public ActionResult RegisterOrChangeDetails(UserViewModel userToAdd)
        {
            User user;
            if (Request.Cookies["UserInfo"] != null)
            {
                int id;
                string cookieID = Request.Cookies["UserInfo"]["ID"];
                if (int.TryParse(cookieID, out id))
                {
                    userToAdd.UserName = _loginManager.FindUserByID(id).UserName;
                    user = Services.Services.ConverVMUserToUser(userToAdd, id);
                    TempData["AlertMessage"] = _loginManager.ChangeDetails(user);
                    return View("Profile", userToAdd);
                }
            }
            user = Services.Services.ConverVMUserToUser(userToAdd, -1);
            TempData["AlertMessage"] = _loginManager.AddUser(user);
            return View("Profile", userToAdd);
        }

        [HttpGet]
        [MyFilter]
        public ActionResult Details(int productID)
        {
            Product product = _productManager.FindProduct(productID);
            if(product!=null)
                return View("Details", product);
            TempData["AlertMessage"] = "Product was not found";
            return RedirectToAction("Index");
        }
        [MyFilter]
        [HttpGet]
        public ActionResult AddToCart(int productID)
        {
            List<int> cartIds;
            if (Request.Cookies["cart"]==null)
                cartIds = new List<int>();
            else
                cartIds = JsonConvert.DeserializeObject<List<int>>(Request.Cookies["cart"].Value);
            cartIds.Add(productID);
            int id;
            string cookieID;
            if (Request.Cookies["UserInfo"] != null)
                cookieID = Request.Cookies["UserInfo"]["ID"];
            else
                cookieID = "";
            bool flagID = int.TryParse(cookieID, out id);
            if (flagID)
                TempData["AlertMessage"] = _productManager.AddToCart(_productManager.FindProduct(productID), _loginManager.FindUserByID(id));
            else
                TempData["AlertMessage"] = _productManager.AddToCart(_productManager.FindProduct(productID), null);
            HttpCookie userCookie = Response.Cookies["cart"];
            userCookie.Value = JsonConvert.SerializeObject(cartIds);
            return RedirectToAction("Cart");
        }
        [MyFilter]
        [HttpGet]
        public ActionResult RemoveFromCart(int productID)
        {
            List<int> cartIds;
            if (Request.Cookies["cart"] == null)
            {
                cartIds = new List<int>();
                TempData["AlertMessage"] = "Cart is empty!";
            }
            else
            {
                cartIds =JsonConvert.DeserializeObject<List<int>>(Request.Cookies["cart"].Value);
                cartIds.Remove(productID);
                _productManager.RemoveFromCart(_productManager.FindProduct(productID));
            }
            HttpCookie userCookie = Response.Cookies["cart"];
            userCookie.Value = JsonConvert.SerializeObject(cartIds);
            return RedirectToAction("Cart");
        }
        [MyFilter]
        public ActionResult Cart()
        {
            List<int> cartIds;
            if (Request.Cookies["cart"] == null)
            {
                cartIds = new List<int>();
                TempData["AlertMessage"] = "Cart is empty!";
            }
            else
                cartIds = JsonConvert.DeserializeObject<List<int>>(Request.Cookies["cart"].Value);
            List<Product> productsInCart = new List<Product>();
            foreach(var id in cartIds)
            {
                productsInCart.Add(_productManager.FindProduct(id));
            }
            return View("Cart", productsInCart);
        }
        [MyFilter]
        public ActionResult Buy()
        {
            List<int> cartIds;
            if (Request.Cookies["cart"] == null)
                TempData["AlertMessage"] = "Cart is empty!";
            else
            {
                cartIds = JsonConvert.DeserializeObject<List<int>>(Request.Cookies["cart"].Value);
                
                int id;
                string cookieID;
                if (Request.Cookies["UserInfo"] != null)
                    cookieID = Request.Cookies["UserInfo"]["ID"];
                else
                    cookieID = "";
                bool flagID = int.TryParse(cookieID, out id);
                foreach (var itemId in cartIds)
                {
                    if(flagID)
                        _productManager.Buy(_productManager.FindProduct(itemId), _loginManager.FindUserByID(id));
                    else
                        _productManager.Buy(_productManager.FindProduct(itemId), null);
                }
            }
            cartIds = new List<int>();
            HttpCookie userCookie = Response.Cookies["cart"];
            userCookie.Value = JsonConvert.SerializeObject(cartIds);
            return RedirectToAction("Index");
        }
    }
}