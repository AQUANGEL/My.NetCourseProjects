﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Config
    {
        private static readonly string CurrentDirectoryPath = AppDomain.CurrentDomain.BaseDirectory;
        private static readonly string DataFolderPath = Path.GetFullPath(Path.Combine(CurrentDirectoryPath, @"..\..\.."));
        public static readonly string DBLogFilePath = string.Format("{0}{1}", DataFolderPath, @"\DBLog.txt");
        public static readonly string ClientLogFilePath = string.Format("{0}{1}", DataFolderPath, @"\ClientLog.txt");

    }
}
