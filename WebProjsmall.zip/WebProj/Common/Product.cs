﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Product
    {
        [Key]
        [Display(AutoGenerateField = false)]
        public int ProductId { get; set; }
        [Required]
        [Display(AutoGenerateField = false)]
        public int OwnerId { get; set; }
        [ForeignKey("OwnerId")]
        [Display(AutoGenerateField = false)]
        public virtual User Owner { get; set; }
        [Display(AutoGenerateField = false)]
        public virtual User Buyer { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper title"), MaxLength(50)]
        [DisplayName("Title")]
        public string Title { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper Description"), MaxLength(500)]
        [DisplayName("Short Description")]
        public string ShortDescription { get; set; }
        [DisplayName("Long Description")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper Description"), MaxLength(4000)]
        public string LongDescription { get; set; }
        [Required]
        [DisplayName("Publication Date")]
        public DateTime Date { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter proper price")]
        [DisplayName("Price")]
        public double Price { get; set; }
        public byte[] Image1 { get; set; }
        public byte[] Image2 { get; set; }
        public byte[] Image3 { get; set; }

        [Required]
        [Display(AutoGenerateField = false)]
        public int State { get; set; }
    }
}
