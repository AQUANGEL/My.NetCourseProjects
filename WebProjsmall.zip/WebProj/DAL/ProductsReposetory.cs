﻿using Common;
using DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ProductsReposetory:IProductReposetory
    {

        public IEnumerable<Product> GetAllProducts()
        {
            using (var context = new MyWebDBEntities())
            {
                return context.Products.ToList(); 
            }
            throw new System.ArgumentException("Lost connection");
        }

        public IEnumerable<Product> GetProductsByRange(int first, int last)
        {
            using (var context = new MyWebDBEntities())
            {
                var products = (from product in context.Products
                               where product.ProductId>=first&&product.ProductId<=last
                               select product).ToList();
                return products;
            }
            throw new System.ArgumentException("Lost connection");
        }

        public bool AddProduct(Product productToAdd)
        {
            using (var context = new MyWebDBEntities())
            {
                if(FindProduct(productToAdd.ProductId)==null)
                {
                    context.Products.Add(productToAdd);
                    context.SaveChanges();
                    return true;
                }
                throw new System.ArgumentException("Product Already Exist!");
            }
            throw new System.ArgumentException("Lost connection");
        }

        public Product FindProduct(int productID)
        {
            using (var context = new MyWebDBEntities())
            {
                var product = context.Products.Where(p => p.ProductId == productID).FirstOrDefault();
                if (product != null)
                    return product;
                return null;
            }
            throw new System.ArgumentException("Lost connection");
        }

        public bool ChangeProduct(Product productToChange)
        {
            using (var context = new MyWebDBEntities())
            {
                Product product = FindProduct(productToChange.ProductId);
                product.Buyer = productToChange.Buyer;
                product.Image1 = productToChange.Image1;
                product.Image2 = productToChange.Image2;
                product.Image3 = productToChange.Image3;
                product.LongDescription = productToChange.LongDescription;
                product.ShortDescription = productToChange.ShortDescription;
                product.State = productToChange.State;
                product.Title = productToChange.Title;
                context.Products.Attach(product);
                context.Entry(product).State = EntityState.Modified;
                context.SaveChanges();
                return true;
            }
            throw new System.ArgumentException("Product not found!");
        }
    }
}
