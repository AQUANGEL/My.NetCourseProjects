﻿using Common;
using DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class UsersReposetory:IUserReposetory
    {

        public User FindUser(string userName)
        {
            using (var context = new MyWebDBEntities())
            {
                User result = (from user in context.Users
                               where userName == user.UserName
                               select user).FirstOrDefault();
                if (result != null)
                    return result;
                else
                    return null;
            }
            throw new System.ArgumentException("Lost connection");
        }

        public User FindUserByID(int id)
        {
            using (var context = new MyWebDBEntities())
            {
                User result = (from user in context.Users
                               where id == user.UserId
                               select user).FirstOrDefault();
                if (result != null)
                    return result;
                else
                    return null;
            }
            throw new System.ArgumentException("Lost connection");
        }

        public bool AddUser(User userToAdd)
        {
            using (var context = new MyWebDBEntities())
            {
                if (FindUser(userToAdd.UserName) == null)
                {
                    context.Users.Add(userToAdd);
                    context.SaveChanges();
                    return true;
                }
                else
                    throw new System.ArgumentException("User already exist");

            }
            throw new System.ArgumentException("Lost connection");
        }

        public bool ChangeUserDetails(User userToChange)
        {
            using (var context = new MyWebDBEntities())
            {
                User user = FindUserByID(userToChange.UserId);
                if(user!=null)
                {
                    user.FirstName = userToChange.FirstName;
                    user.LastName = userToChange.LastName;
                    user.BirthDate = userToChange.BirthDate;
                    user.Email = userToChange.Email;
                    user.Password = userToChange.Password;
                    context.Users.Attach(user);
                    context.Entry(user).State = EntityState.Modified;
                    context.SaveChanges();
                    return true;
                }
                throw new System.ArgumentException("User not found");
            }
            throw new System.ArgumentException("Lost connection");
        }

        public bool Login(string userName, string password)
        {
            using (var context = new MyWebDBEntities())
            {
                User userToLog = FindUser(userName);
                if (userToLog != null)
                {
                    if (userToLog.Password == password)
                        return true;
                    else
                        throw new System.ArgumentException("Wrong Password!");
                }
                throw new System.ArgumentException("Wrong Details!");
            }
            throw new System.ArgumentException("Lost connection");
        }

    }
}
