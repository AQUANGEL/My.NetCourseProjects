﻿using Common;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    internal class DbInitializer: DropCreateDatabaseIfModelChanges<MyWebDBEntities>
    {
        protected override void Seed(MyWebDBEntities context)
        {
            User u1 = new User();
            u1.UserName = "u1";
            u1.FirstName = "u";
            u1.LastName = "1";
            u1.Password = "u1";
            u1.Email = "u1@sela.com";
            u1.BirthDate = DateTime.Now;

            context.Users.Add(u1);

            Product p1 = new Product();
            p1.OwnerId = u1.UserId;
            p1.Title = "title";
            p1.ShortDescription = "short";
            p1.LongDescription = "long";
            p1.Owner = u1;
            p1.Price = 100;
            p1.State = 1;
            p1.Date = DateTime.Now;

            context.Products.Add(p1);
            context.SaveChanges();
        }
    }
}
