namespace DAL
{
    using Common;
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class MyWebDBEntities : DbContext
    {
        public  DbSet<User> Users { get; set; }
        public  DbSet<Product> Products { get; set; }

        public MyWebDBEntities()
            : base("name=MyWebDBEntities")
        {
            Database.SetInitializer<MyWebDBEntities>(new DbInitializer());
        }

        
    }

    
}