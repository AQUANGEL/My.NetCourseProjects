﻿using Common;
using DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BL
{
    public class ProductsManager
    {
        private const int numOfProductsToView = 2;
        private ProductsReposetory repo { get; set; }

        public ProductsManager()
        {
            repo = new ProductsReposetory();
        }

        public Product FindProduct(int id)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                return repo.FindProduct(id);
            }
            catch (System.ArgumentException e)
            {
                status.Append(e);
            }
            catch (Exception e)
            {
                status.Append(e);
            }
            LogExceptions(status.ToString());
            return null;
        }

        public string AddProduct(Product productToAdd)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                if (repo.AddProduct(productToAdd))
                    status.Append("Added");
            }
            catch(System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration");
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public string AddToCart(Product productToCart, User buyer)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                productToCart.State = 2;
                productToCart.Buyer = buyer;
                if (repo.ChangeProduct(productToCart))
                    status.Append("Added");
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration");
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public string RemoveFromCart(Product productInCart)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                productInCart.State = 1;
                productInCart.Buyer = null;
                if (repo.ChangeProduct(productInCart))
                    status.Append("Added");
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration");
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public string Buy(Product productToBuy, User buyer)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                productToBuy.State = 3;
                productToBuy.Buyer = buyer;
                if (repo.ChangeProduct(productToBuy))
                    status.Append("Sold");
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration");
                LogExceptions(e.Message);
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public IEnumerable<Product> GetAllProducts()
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                return repo.GetAllProducts();

            }
            catch(System.ArgumentException e)
            {
                status.Append(e);
            }
            catch(Exception e)
            {
                status.Append(e);
            }
            LogExceptions(status.ToString());
            return new List<Product>();
        }

        public IEnumerable<Product> GetAllProductsByRange(Product currentProduct)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                int first = currentProduct.ProductId, last = first + numOfProductsToView;
                return repo.GetProductsByRange(first, last);
            }
            catch (System.ArgumentException e)
            {
                status.Append(e);
            }
            catch (Exception e)
            {
                status.Append(e);
            }
            LogExceptions(status.ToString());
            return new List<Product>();
        }

        private void LogExceptions(string exception)
        {
            if (!File.Exists(Config.DBLogFilePath))
            {
                using (StreamWriter sw = File.CreateText(Config.DBLogFilePath))
                {
                    sw.WriteLine(exception);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(Config.DBLogFilePath))
                {
                    sw.WriteLine(exception);
                }
            }
        }

    }
}
