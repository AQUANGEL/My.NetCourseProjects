﻿using Common;
using DAL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    public class LoginManager
    {
        private UsersReposetory repo { get; set; }

        public LoginManager()
        {
            repo = new UsersReposetory();
        }

        public string AddUser(User userToAdd)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                if (repo.AddUser(userToAdd))
                    status.Append("Added");
            }
            catch(System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch(Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration " + e.Message);
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public string Login(string userName, string password)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                if (repo.Login(userName, password))
                    status.Append("Login");
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration " + e.Message);
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public string ChangeDetails(User userNewDetails)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                if (repo.ChangeUserDetails(userNewDetails))
                    status.Append("Details Changed");
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration " + e.Message);
            }
            LogExceptions(status.ToString());
            return status.ToString();
        }

        public User FindUser(string userName)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                return repo.FindUser(userName);
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration " + e.Message);
            }
            LogExceptions(status.ToString());
            throw new System.ArgumentException("User not found");
        }

        public User FindUserByID(int id)
        {
            StringBuilder status = new StringBuilder("");
            try
            {
                return repo.FindUserByID(id);
            }
            catch (System.ArgumentException e)
            {
                status.Append(e.Message.ToString());
            }
            catch (Exception e)
            {
                if (status.ToString().Equals(""))
                    status.Append("Unexpected error has occured plaese contact system adminestration " + e.Message);
            }
            LogExceptions(status.ToString());
            throw new System.ArgumentException("User not found");
        }

        private void LogExceptions(string exception)
        {
            if (!File.Exists(Config.DBLogFilePath))
            {
                using (StreamWriter sw = File.CreateText(Config.DBLogFilePath))
                {
                    sw.WriteLine(exception + "\n");
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(Config.DBLogFilePath))
                {
                    sw.WriteLine(exception + "\n");
                }
            }
        }
    }
}
