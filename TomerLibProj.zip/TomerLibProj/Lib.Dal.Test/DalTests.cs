﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using LibCommon.Items;
using System.IO;

namespace Lib.Dal.Test
{
    [TestClass]
    public class DalTests
    {
        private FileManager _fm;
        private ItemsInventory _inventory;
        private static readonly string CurrentDirectoryPath = Directory.GetCurrentDirectory();
        private static readonly string DataFolderPath = Path.GetFullPath(Path.Combine(CurrentDirectoryPath, @"..\..\.."));
        public static readonly string TestSave = string.Format("{0}{1}", DataFolderPath, @"\TestSave.txt");
        public static readonly string TestLoad = string.Format("{0}{1}", DataFolderPath, @"\TestLoad.txt");


        [TestMethod]
        public void SaveTest()
        {
            ////Arrange
            Mock<IFileManager> mock = new Mock<IFileManager>();
            var target = mock.Object;
            List<Item> l = new List<Item>();
            mock.Setup(x => x.SaveInventory(l, TestSave));

            ////Act
            target.SaveInventory(l, TestSave);


            ////Assert
            mock.Verify(x => x.SaveInventory(l, TestSave), Times.Once);

        }

        [TestMethod]
        public void LoadTest()
        {
            ////Arrange
            Mock<IFileManager> mock = new Mock<IFileManager>();
            var target = mock.Object;
            
            mock.Setup(x => x.LoadInventory(TestLoad));

            ////Act
            target.LoadInventory(TestLoad);


            ////Assert
            mock.Verify(x => x.LoadInventory(TestLoad), Times.Once);
        }


        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void TestUpdateNull()
        {
            _inventory = new ItemsInventory();

            _inventory.UpdateItem(null);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void TestBorrowNull()
        {
            _inventory = new ItemsInventory();

            _inventory.BorrowItem(null);
        }
    }
}
