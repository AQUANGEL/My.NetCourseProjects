﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.ENums
{
    [Serializable()]
    public enum StudyCatag
    {
        Math,
        Science,
        Literature,
        Programming,
        Economy,
        Psychology,
    }
}
