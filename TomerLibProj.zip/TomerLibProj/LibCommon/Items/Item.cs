﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Items
{
    [Serializable()]
    public class Item
    {
        public int _barcode { get; protected set; }
        public string _type { get; protected set; }
        public string _name { get; protected set; }
        public int _ammount { get; protected set; }
        public DateTime _publicationDate { get; protected set; }

        public Item(int barcode, string name, int ammount, DateTime publicationDate)
        {
            StringBuilder exc = new StringBuilder("");
            if (barcode >= 1)
            {
                _barcode = barcode;
            }
            else
            {
                exc.Append("Invalid barcode, must be pos num \n");
            }
           
            _type = "Item";
            if(name!=null&&!name.Equals(""))
            {
                _name = name;
            }
            else
            {
                exc.Append("Invalid name, must be string \n");
            }

            if (ammount>=0)
            {
                _ammount = ammount;
            }
            else
            {
                exc.Append("Invalid amount, must be pos num \n");
            }
            if(publicationDate.CompareTo(DateTime.Now)<=0)
            {
                _publicationDate = publicationDate;
            }
            else
            {
                exc.Append("Invalid date, must be before current date \n");
            }
            if(!exc.ToString().Equals(""))
            {
                throw new System.ArgumentException(exc.ToString());
            }
        }
        /*
         * Update the item details
         */
        public virtual void UpdateItem(Item item)
        {
            //_type = item._type;
            _name = item._name;
            _ammount = item._ammount;
            _publicationDate = item._publicationDate;
        }
        /*
         * Remove the num from the item amount
         */
        public void Borrow(int num)
        {
            if (num < 0)
            {
                if (Math.Abs(num) <= _ammount)
                    _ammount += num;
                else
                    throw new System.ArgumentException("Not enough in stock");
            }
            else
                throw new System.ArgumentException("Illeagal amount");
            
        }
        /*
         * add the num to the item amount
         */
        public void Add(int num)
        {
            if (num > 0)
                _ammount += num;
            else
                throw new System.ArgumentException("Illeagal amount");

        }
        /*
         * compares the isbn/barcode and the item type
         */
        public override bool Equals(object obj)
        {
            if(obj is Item)
            {
                Item toCompare = (Item)obj;
                if (_barcode == toCompare._barcode&&_type.Equals(toCompare._type))
                    return true;
            }
            return false;
        }

        public override string ToString()
        {
            return string.Format("Item type is {0}, Isbn is {1}, Name is {2}, Amount is {3}, Date is {4}", _type, _barcode, _name, _ammount, _publicationDate.ToString());
        }

    }
}
