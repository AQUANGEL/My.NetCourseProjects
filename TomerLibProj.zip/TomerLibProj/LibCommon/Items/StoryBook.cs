﻿using LibCommon.ENums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Items
{
    [Serializable()]
    public class StoryBook : Book
    {
        public StoryCatag _Catag { get; protected set; }

        public StoryBook(int barcode, string name, int ammount, DateTime publicationDate, string author, bool bestSeller , StoryCatag catag)
            : base(barcode, name, ammount, publicationDate, author, bestSeller)
        {
            base._type = "StoryBook";
            _Catag = catag;
        }
        /*
         * Updates the Story book
         */
        public void UpdateItem(Item item)
        {
            base.UpdateItem(item);
            if(item is StoryBook)
            {
                _Catag = ((StoryBook)item)._Catag;
            }
        }

        public override string ToString()
        {
            StringBuilder s = new StringBuilder(base.ToString());
            s.Append(string.Format(", Story catagory is {0}", _Catag.ToString()));
            return s.ToString();
        }
    }
}
