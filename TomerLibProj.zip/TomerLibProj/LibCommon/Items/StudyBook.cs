﻿using LibCommon.ENums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Items
{
    [Serializable()]
    public class StudyBook : Book
    {
        public StudyCatag _Catag { get; protected set; }

        public StudyBook(int barcode, string name, int ammount, DateTime publicationDate, string author, bool bestSeller, StudyCatag catag)
            : base(barcode, name, ammount, publicationDate, author, bestSeller)
        {
            base._type = "StudyBook";
            _Catag = catag;
        }


        /*
         * Updates the Study book
         */
        public void UpdateItem(Item item)
        {
            base.UpdateItem(item);
            if (item is StudyBook)
            {
                _Catag = ((StudyBook)item)._Catag;
            }
        }

        public override string ToString()
        {
            StringBuilder s = new StringBuilder(base.ToString());
            s.Append(string.Format(", Study catagory is {0}" , _Catag.ToString()));
            return s.ToString();
        }
    }
}
