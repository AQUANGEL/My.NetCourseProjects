﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Items
{
    [Serializable()]
    public class Journal : Item
    {
        public Journal(int barcode, string name, int ammount, DateTime publicationDate) 
            : base(barcode, name, ammount, publicationDate)
        {
            _type = "Journal";
        }
    }
}
