﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Items
{
    [Serializable()]
    public class Book : Item
    {
        public string _author { get; protected set; }
        public bool _bestSeller { get; protected set; } 

        public Book(int barcode, string name, int ammount, DateTime publicationDate, string author, bool bestSeller) 
            : base(barcode, name, ammount, publicationDate)
        {
            base._type = "Book";
            if(author!=null&&!author.Equals(""))
            {
                _author = author;
            }
            else
            {
                throw new System.ArgumentException("Illeagal author name");
            }
            
            _bestSeller = _bestSeller;
        }
        /*
         * Updates the book
         */
        public void UpdateItem(Item item)
        {
            base.UpdateItem(item);
            if(item is Book)
            {
                _author = ((Book)item)._author;
                _bestSeller = ((Book)item)._bestSeller;
            }
        }

        public override string ToString()
        {
            StringBuilder s = new StringBuilder(base.ToString() + " ");
            s.Append(string.Format(", Author name is {0}, Is best selles = {1}", _author, _bestSeller));
            return s.ToString();
        }
    }
}
