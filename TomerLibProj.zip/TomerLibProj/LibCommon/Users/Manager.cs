﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Users
{
    public class Manager : BasicUser, ICanAddAndUpdate, ICanDelete
    {
        public Manager(string name, string password) : base(name, password)
        {
        }
    }
}
