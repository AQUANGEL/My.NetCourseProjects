﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Users
{
    public class Librarian : BasicUser, ICanAddAndUpdate
    {
        public Librarian(string name, string password) : base(name, password)
        {

        }
    }
}
