﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibCommon.Users
{
    public class BasicUser
    {
        public string _name { get; protected set; }
        public string _password { get; protected set; }

        public BasicUser(string name, string password)
        {
            _name = name;
            _password = password;
        }
    }
}
