﻿using Lib.Dal;
using LibCommon;
using LibCommon.Items;
using LibCommon.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.BL
{
    public class ControlPanel
    {
        private ItemsInventory _inventory;
        private Users _users;
        private BasicUser _currentUser;

        public ControlPanel()
        {
            _inventory = new ItemsInventory();
            _users = new Users();
        }
        /*
         * Logs into the system
         */
        public bool Login(string name, string password)
        {
            _currentUser = _users.UserLogin(name, password);
            if (_currentUser == null)
                throw new System.ArgumentException("Wrong details");
            return true;
        }
        /*
         * logs out of the system
         */
        public void LogOut() { _currentUser = null; }
        /*
         * gets the inventory by list
         */
        public List<Item> GetInventory()
        {
            if(_currentUser!=null)
            {
                return _inventory.GetInventory();
            }
            throw new System.ArgumentException("Not signed in");
        }
        /*
         * remove the item from inventory
         */
        public void RemoveItem(Item item)
        {
            if (_currentUser != null)
            {
                if (_currentUser is ICanDelete)
                {
                    _inventory.RemoveItem(item);

                }
                else
                {
                    throw new System.ArgumentException("No permission");
                }
            }
            else
            {
                throw new System.ArgumentException("Not signed in");
            }
            
            
        }
        /*
         * add the item to inventory
         */
        public void AddItem(Item item)
        {
            if (_currentUser != null)
            {
                if (_currentUser is ICanAddAndUpdate)
                {
                    _inventory.AddItem(item);
                }
                else
                {
                    throw new System.ArgumentException("No permission");
                }
            }
            else
            {
                throw new System.ArgumentException("Not signed in");
            }

        }
        /*
         * borrow the item, reduce amount by 1
         */
        public void Borrow(Item item)
        {
            if (_currentUser != null)
            {
                _inventory.BorrowItem(item);
            }
            else
            {
                throw new System.ArgumentException("Not signed in");
            }
        }

        public void UpdateItem(Item item)
        {
            if (_currentUser != null)
            {
                if (_currentUser is ICanAddAndUpdate)
                {
                    _inventory.UpdateItem(item);

                }
                else
                {
                    throw new System.ArgumentException("No permission");
                }
            }
            else
            {
                throw new System.ArgumentException("Not signed in");
            }

        }

        public bool CanDelete()
        {
            if (_currentUser is ICanDelete)
                return true;
            return false;
        }

        public bool CanAdd()
        {
            if (_currentUser is ICanAddAndUpdate)
                return true;
            return false;
        }
    }
}
