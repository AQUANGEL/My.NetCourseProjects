﻿using LibCommon.ENums;
using LibCommon.Items;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibClient
{
    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int amount;
            int barcode;
            if(!int.TryParse(BarCodeTxt.Text, out barcode))
            {
                MessageBox.Show("Illeagal input");
            }
            string name = NameTxt.Text;
            if (!int.TryParse(AmountTxt.Text, out amount))
            {
                MessageBox.Show("Illeagal input");
            }
            
            
            
            DateTime pubDate = new DateTime(PubDate.SelectedDate.Value.Year, PubDate.SelectedDate.Value.Month, PubDate.SelectedDate.Value.Day);

            if (TypeCombo.SelectedItem.Equals("Book"))
            {
                string author = AuthorTxt.Text;
                
                bool isBS = checkBoxIBS.IsChecked ?? false;
                if (BookTypeCombo.SelectedItem.Equals("Study"))
                {
                    try
                    {
                        StudyCatag s;
                        s = (StudyCatag)Enum.Parse(typeof(StudyCatag), SubBookTypeCombo.SelectedItem.ToString());
                        LoginWindow._Ctrl.AddItem(new StudyBook(barcode, name, amount, pubDate, author, isBS,s));
                        //MainWindow._collection.Add(new StudyBook(barcode, name, amount, pubDate, author, isBS,Enum.Parse( ));
                    }
                    catch (System.ArgumentException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    
                }
                else
                {
                    if(BookTypeCombo.SelectedItem.Equals("Story"))
                    {
                        try
                        {
                            StoryCatag s;
                            s = (StoryCatag)Enum.Parse(typeof(StoryCatag), SubBookTypeCombo.SelectedItem.ToString());
                            LoginWindow._Ctrl.AddItem(new StoryBook(barcode, name, amount, pubDate, author, isBS, s));
                            
                        }
                        catch (System.ArgumentException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
            }
            else
            {
                if (TypeCombo.SelectedItem.Equals("Journal"))
                {
                    try
                    {
                        LoginWindow._Ctrl.AddItem(new Journal(barcode, name, amount, pubDate));
                        
                    }
                    catch (System.ArgumentException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AuthorTxt.IsEnabled = false;
            checkBoxIBS.IsEnabled = false;
            BookTypeCombo.IsEnabled = false;
            SubBookTypeCombo.IsEnabled = false;
            AddBtn.IsEnabled = false;
            PubDate.IsEnabled = false;
            TypeCombo.Items.Add("Book");
            TypeCombo.Items.Add("Journal");

        }

        

        private void TypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TypeCombo.SelectedItem.Equals("Book"))
            {
                AuthorTxt.IsEnabled = true;
                checkBoxIBS.IsEnabled = true;
                BookTypeCombo.Items.Add("Story");
                BookTypeCombo.Items.Add("Study");
                BookTypeCombo.IsEnabled = true;
                AddBtn.IsEnabled = false;
                PubDate.IsEnabled = true;
                //SubBookTypeCombo.IsEnabled = true;
            }
            else
            {
                if (TypeCombo.SelectedItem.Equals("Journal"))
                {
                    AuthorTxt.IsEnabled = false;
                    checkBoxIBS.IsEnabled = false;
                    BookTypeCombo.IsEnabled = false;
                    SubBookTypeCombo.IsEnabled = false;
                    AddBtn.IsEnabled = true;
                    PubDate.IsEnabled = true;
                }
            }
        }

        private void BookTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string[] catag;
            if (BookTypeCombo.SelectedItem.Equals("Study"))
            {
                catag = Enum.GetNames(typeof(StudyCatag));
                for(int i = 0 ; i<catag.Length; i++)
                {
                    SubBookTypeCombo.Items.Add(catag[i]);
                }
                SubBookTypeCombo.IsEnabled = true;
                BookTypeCombo.IsEnabled = false;
            }
            else
            {
                if (BookTypeCombo.SelectedItem.Equals("Story"))
                {
                    catag = Enum.GetNames(typeof(StoryCatag));
                    for (int i = 0; i < catag.Length; i++)
                    {
                        SubBookTypeCombo.Items.Add(catag[i]);
                    }
                    SubBookTypeCombo.IsEnabled = true;
                    BookTypeCombo.IsEnabled = false;
                }
            }
        }

        private void SubBookTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AddBtn.IsEnabled = true;
        }
    }
}
