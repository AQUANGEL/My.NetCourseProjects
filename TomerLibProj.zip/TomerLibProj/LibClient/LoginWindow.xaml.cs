﻿using Lib.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibClient
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        internal static ControlPanel _Ctrl = new ControlPanel();
        
        public LoginWindow()
        {
            InitializeComponent();
        }
        /*
         * logs in to the system or do nothing if the log in details are wrong
         * 
         */
        private void Login_Btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_Ctrl.Login(UserNameText.Text, PasswordText.Text))
                {
                    MainWindow mn = new MainWindow();
                    mn.ShowDialog();
                }
            }
            catch(System.ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            
        }
    }
}
