﻿using Lib.BL;
using LibCommon.Items;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LibClient
{
    
    public partial class MainWindow : Window
    {
        internal static ObservableCollection<Item> _collection;

        public MainWindow()
        {
            InitializeComponent();
            
        }
        /*
         * updates the grid at startup
         */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
            if (LoginWindow._Ctrl.CanAdd())
                AddBtn.IsEnabled = true;
            else
                AddBtn.IsEnabled = false;
            if (LoginWindow._Ctrl.CanDelete())
                RemoveBtn.IsEnabled = true;
            else
                RemoveBtn.IsEnabled = false;
        }
        /*
         * adding a new item
         */
        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                AddWindow ad = new AddWindow();
                ad.ShowDialog();
                this.Show();
                LoadGrid();
            }
            catch (System.ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /*
         * borrows a book
         * 
         */
        private void BorrowBtn_Click(object sender, RoutedEventArgs e)
        {
            if(ItemsGrid.SelectedItem is Item)
            {
                try
                {
                    Item toBorrow = (Item)ItemsGrid.SelectedItem;

                    LoginWindow._Ctrl.Borrow(toBorrow);
                    LoadGrid();
                }
                catch (System.ArgumentException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
        /*
         * Removes a book
         */
        private void RemoveBtn_Click(object sender, RoutedEventArgs e)
        {
            if (ItemsGrid.SelectedItem is Item)
            {
                try
                {
                    Item toRemove = (Item)ItemsGrid.SelectedItem;
                    LoginWindow._Ctrl.RemoveItem(toRemove);

                    LoadGrid();
                }
                catch (System.ArgumentException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }
        /*
         * searches the text from the textbox in the items names
         * 
         */
        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(SearchBox.Text.Equals(""))
            {
                LoadGrid();
            }
            else
            {
                try
                {
                    _collection = new ObservableCollection<Item>(
                LoginWindow._Ctrl.GetInventory().Where(item => item._name.Contains(SearchBox.Text)));
                    ItemsGrid.ItemsSource = _collection;
                    ItemsGrid.Items.Refresh();
                    ClearDetails();
                }
                catch (System.ArgumentException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
            
        }
        /*
         * load the grid after changes
         */
        private void LoadGrid()
        {
            try
            {
                _collection = new ObservableCollection<Item>(LoginWindow._Ctrl.GetInventory());
                ItemsGrid.ItemsSource = _collection;
                ItemsGrid.Items.Refresh();
                ClearDetails();
            }
            catch (System.ArgumentException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        /*
         * show current chosen item details
         */
        private void ItemsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ItemsGrid.SelectedItem is Item)
            {
                Item toText = (Item)ItemsGrid.SelectedItem;
                ItemInfoDetailsBlk.Text = toText.ToString();
            }
        }

        private void ClearDetails()
        {
            ItemInfoDetailsBlk.Text = "";
        }
    }
}
