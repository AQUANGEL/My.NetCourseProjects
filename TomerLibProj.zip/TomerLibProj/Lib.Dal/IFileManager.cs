﻿using LibCommon.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.Dal
{
    public interface IFileManager
    {
        List<Item> LoadInventory(string filePath);

        void SaveInventory(List<Item> inventory, string filePath);
    }
}
