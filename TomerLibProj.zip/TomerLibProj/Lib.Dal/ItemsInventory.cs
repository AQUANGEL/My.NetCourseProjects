﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibCommon.Items;

namespace Lib.Dal
{
    public class ItemsInventory
    {

        private List<Item> _ItemIneventory;
        private IFileManager _FM;

        public ItemsInventory()
        {
            _FM = new FileManager();
            _ItemIneventory = LoadInventory();
        }
        /*
         * returns the items list
         */
        public List<Item> GetInventory()
        {
            return _ItemIneventory;
        }
        /*
         * loading the list using the file manager
         */
        private List<Item> LoadInventory()
        {
            List<Item> loadedList = null;
            try
            {
                loadedList = _FM.LoadInventory(Config.InventoryFilePath);
                
            }
            catch(System.ArgumentException)
            {
                return new List<Item>();
            }
            return loadedList;
        }
        /*
         * saving the list using the file manager
         */
        private void Save()
        {
            _FM.SaveInventory(_ItemIneventory, Config.InventoryFilePath);
        }
        /*
         * Add a new item or update an existing item details (if its equal to an existing item in the list)
         */
        public void AddItem(Item itemToAdd)
        {
            int index = _ItemIneventory.FindIndex(item => item.Equals(itemToAdd));
            if(index>-1)
            {
                _ItemIneventory[index].UpdateItem(itemToAdd);
            }
            else
            {
                _ItemIneventory.Add(itemToAdd);
            }
            Save();
        }
        /*
         * Removes an existing item
         */
        public void RemoveItem(Item itemToRemove)
        {
            _ItemIneventory.Remove(itemToRemove);
            Save();
        }
        /*
         * Updates an item (Not used in project)
         */
        public void UpdateItem(Item itemToUpdate)
        {
            if (itemToUpdate != null)
            {
                int index = _ItemIneventory.FindIndex(item => item.Equals(itemToUpdate));
                if (index > -1)
                {
                    _ItemIneventory[index].UpdateItem(itemToUpdate);
                    Save();
                }
            }
            else
                throw new NullReferenceException("Please send an item");
        }
        /*
         * Borrows a certain amount of items
         */
        public void BorrowItem(Item itemToBorrow,int amountToBorrow = -1)
        {
            if(itemToBorrow!=null)
            {
                int index = _ItemIneventory.FindIndex(item => item.Equals(itemToBorrow));
                if (index > -1)
                {
                    _ItemIneventory[index].Borrow(amountToBorrow);
                    Save();
                }
            }
            else
                throw new NullReferenceException("Please send an item");


        }
    }
}
