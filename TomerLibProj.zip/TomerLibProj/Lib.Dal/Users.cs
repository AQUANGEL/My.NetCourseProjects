﻿using LibCommon.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.Dal
{
    public class Users
    {
        private List<BasicUser> _users;

        public Users()
        {
            _users = GetUsers();
        }
        /*
         * Defines the users list
         */
        private List<BasicUser> GetUsers()
        {
            List<BasicUser> temp = new List<BasicUser>();
            temp.Add(new BasicUser("User", "User"));
            temp.Add(new Librarian("Librarian","Librarian"));
            temp.Add(new Manager("Manager", "Manager"));
            return temp;
        }
        /*
         * Checks if the login is valid and if it is then return the user
         */
        public BasicUser UserLogin(string name, string password)
        {
            BasicUser temp = _users.Find(user => user._name.Equals(name) && user._password.Equals(password));
            return temp;
        }
    }
}
