﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibCommon.Items;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Lib.Dal
{
    public class FileManager : IFileManager
    {
        IFormatter formatter;
        Stream stream;

        public FileManager()
        {
            formatter = new BinaryFormatter();
            
        }

        /*
         * loading the inventory from configured file path using binary serialization
         */
        public List<Item> LoadInventory(string filePath)
        {
            List<Item> inventoryTemp = null;

            try
            {
                stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
                inventoryTemp = (List<Item>)formatter.Deserialize(stream);
                stream.Close();

            }
            catch(FileNotFoundException)
            {
                throw new System.ArgumentException("Loading exception: File not found");
                stream.Close();
            }
            
            return inventoryTemp;
        }
        /*
         * Saving file to the configured filepath using binary serialization
         */
        public void SaveInventory(List<Item> inventory, string filePath)
        {
            try
            {
                stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None);
                formatter.Serialize(stream, inventory);
                stream.Close();
            }
            catch(SerializationException e)
            {
                throw new System.ArgumentException("Save exception :" + e.Message);
            }
            finally
            {
                stream.Close();
            }
            
        }
    }
}
