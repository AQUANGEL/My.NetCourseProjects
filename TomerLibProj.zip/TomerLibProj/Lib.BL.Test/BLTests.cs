﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LibCommon.Items;
using System.Collections.Generic;

namespace Lib.BL.Test
{
    [TestClass]
    public class BLTests
    {
        private ControlPanel _ctrl;
        private Item i;

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentException))]
        public void GetInventoryTest()
        {
            _ctrl = new ControlPanel();

            _ctrl.GetInventory();
        }

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentException))]
        public void NullLogin()
        {
            _ctrl = new ControlPanel();

            _ctrl.Login(null, null);
            
        }

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentException))]
        public void WrongLogin()
        {
            _ctrl = new ControlPanel();

            _ctrl.Login("", "");

        }


        [TestMethod]
        [ExpectedException(typeof(System.ArgumentException))]
        public void NullUpdateItem()
        {
            _ctrl = new ControlPanel();
            //_ctrl.Login("Manager", "Manager");

            _ctrl.UpdateItem(null);

        }
    }
}
