import { Component, OnInit } from '@angular/core';
import { Item } from '../WishListItem';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.component.html',
  styleUrls: ['./wish-list.component.css']
})
export class WishListComponent implements OnInit {
  counterID: number;
  constructor(private Service: ServicesService) {
    this.counterID = 0;
   }
   get ItemsList() {
     return this.Service.GetList();
   }

   Add(name: string, link: string) {
     this.Service.List.push(new Item(name, link, this.counterID));
     this.counterID++;
     this.Service.SaveList();
   }

   Delete(item: Item) {
      this.Service.List = this.ItemsList.filter(i => i.id !== item.id);
      this.Service.SaveList();
   }
  ngOnInit() {
  }

}
