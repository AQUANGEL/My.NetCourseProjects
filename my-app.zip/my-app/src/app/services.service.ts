import { Injectable } from '@angular/core';
import { Item } from './WishListItem';

@Injectable()
export class ServicesService {
  List: Item[];
  constructor() {
      this.List = [];
  }
  SaveList() {
    localStorage.setItem('List', JSON.stringify(this.List));
  }

  LoadList() {
      this.List = JSON.parse(localStorage.getItem('List'));
  }
  GetList() {
    this.LoadList();
    if (this.List === null) {
      this.List = [];
    }
    return this.List;
  }
}
