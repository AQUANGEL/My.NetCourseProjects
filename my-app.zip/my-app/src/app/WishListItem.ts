export class Item {
    name: string;
    link: string;
    id: number;
    state: boolean;

    constructor(name: string, link: string, id: number) {
        this.name = name;
        this.link = link;
        this.id = id;
        this.state = false;
    }
}
