import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Item } from '../WishListItem';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-wish-item',
  templateUrl: './wish-item.component.html',
  styleUrls: ['./wish-item.component.css']
})
export class WishItemComponent implements OnInit {
  @Input() item: Item;
  @Output() changed: EventEmitter<any> = new EventEmitter();
  constructor(private Service: ServicesService) {
  }
  Change() {
    if (this.item.state == false) {
      this.item.state = true;
      this.Service.List.find(i => i.id === this.item.id).state = true;
      this.Service.SaveList();
    } else {
        this.changed.emit(this.item);
    }
  }
  ngOnInit() {
  }

}
