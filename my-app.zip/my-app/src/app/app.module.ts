import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { WishListComponent } from './wish-list/wish-list.component';
import { ServicesService} from './services.service';
import { WishItemComponent } from './wish-item/wish-item.component';

@NgModule({
  declarations: [
    AppComponent,
    WishListComponent,
    WishItemComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [{provide: ServicesService, useClass: ServicesService}],
  bootstrap: [AppComponent]
})
export class AppModule { }
